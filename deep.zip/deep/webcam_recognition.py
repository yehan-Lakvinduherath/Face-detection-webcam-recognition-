import cv2
from deepface import DeepFace
import os
import numpy as np

# Path to known faces folder
known_faces_path = "known_faces"

print("Loading known faces...")

# Function to load embeddings and names from known faces folder
def load_known_faces(known_faces_path):
    embeddings = []
    names = []
    for file in os.listdir(known_faces_path):
        if file.endswith((".jpg", ".png", ".jpeg")):
            img_path = os.path.join(known_faces_path, file)
            print(f"Processing {file} ...")
            embedding = DeepFace.represent(img_path, enforce_detection=False)[0]["embedding"]
            embeddings.append(embedding)
            names.append(os.path.splitext(file)[0])  # filename without extension as name
    return embeddings, names

known_embeddings, known_names = load_known_faces(known_faces_path)

# Cosine similarity function
def cosine_similarity(a, b):
    a = np.array(a)
    b = np.array(b)
    return np.dot(a, b) / (np.linalg.norm(a) * np.linalg.norm(b))

# Open webcam
cap = cv2.VideoCapture(0)

print("Starting webcam... Press 'q' to quit.")

while True:
    ret, frame = cap.read()
    if not ret:
        break

    try:
        result = DeepFace.represent(frame, enforce_detection=False)
    except:
        result = []

    if result:
        face_embedding = result[0]["embedding"]

        # Compare to known faces
        similarities = [cosine_similarity(face_embedding, known_emb) for known_emb in known_embeddings]

        best_idx = np.argmax(similarities)
        best_score = similarities[best_idx]

        threshold = 0.4  # tune this if needed

        if best_score > threshold:
            name = known_names[best_idx]
        else:
            name = "Unknown"

        # Show name on webcam frame
        cv2.putText(frame, name, (50, 50), cv2.FONT_HERSHEY_SIMPLEX, 1, (0,255,0), 2)

    cv2.imshow("Webcam Face Recognition", frame)

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
